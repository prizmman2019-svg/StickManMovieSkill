# Fact check - see-one-minute-ahead

## Claim (one sentence, as it will be said in the episode)
Signals from the eyes take roughly a tenth of a second to be processed, so the visual system extrapolates
moving objects forward: we perceive a predicted position rather than a delayed one.

## Source
- Title: Motion extrapolation in catching
- Publisher / journal, year: Romi Nijhawan, Nature 370, 256-257 (1994)
- URL: https://doi.org/10.1038/370256b0

## Exact quote from the source that supports the claim
(paste the sentence here after opening the URL)

## What the source does NOT say (so we do not overclaim)
It is about fractions of a second and moving objects. It does not say people can foresee events.
Motion extrapolation is one leading explanation of the flash-lag effect; other researchers explain it by
different processing delays (Whitney & Murakami, Nature Neuroscience, 1998). Say "predicts", not "proves".

## Status
NOT VERIFIED BY A HUMAN YET - open the URL and read it before publishing.
