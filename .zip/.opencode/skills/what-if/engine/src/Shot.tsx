import React from 'react';
import {
  ActorSpec,
  ActorState,
  Box,
  H,
  ShotSpec,
  TEXT_STYLE,
  W,
  actorAt,
  bubbleBox,
  cameraAt,
  clamp01,
  formatNumber,
  headBox,
  labelBox,
  labelText,
  propAt,
  resolveFocus,
  GROUND,
} from './layout';
import {Background, PALETTES} from './Background';
import {Character, CharacterDef} from './Character';
import {Prop} from './props';

const INK = '#1b1b22';
export const FONT = '"Arial Black", "Segoe UI Black", "Arial Rounded MT Bold", "Inter", "DejaVu Sans", Arial, sans-serif';

const CROWD_TOPS = ['#8d99ae', '#b5838d', '#6d9dc5', '#a3b18a', '#c9ada7', '#9a8c98', '#84a59d', '#bc8a5f'];

const pop = (frame: number, delay = 0) => {
  const f = Math.max(0, frame - delay);
  const k = Math.min(1, f / 7);
  // overshoot then settle
  return k < 1 ? 0.5 + 0.62 * Math.sin((k * Math.PI) / 1.72) : 1;
};

const Pill: React.FC<{box: Box; text: string; color?: string; frame: number}> = ({box, text, color, frame}) => {
  const palette: Record<string, [string, string]> = {
    green: ['#22b455', '#fff'],
    red: ['#e5383b', '#fff'],
    gold: ['#ffcf3f', INK],
    blue: ['#3a86ff', '#fff'],
    white: ['#ffffff', INK],
    dark: [INK, '#fff'],
  };
  const [bg, fg] = palette[color ?? 'dark'] ?? [color ?? INK, '#fff'];
  const s = pop(frame, 2);
  const cx = box.x + box.w / 2;
  const cy = box.y + box.h / 2;
  const fs = box.h / 1.5;
  return (
    <g transform={`translate(${cx} ${cy}) scale(${s}) translate(${-cx} ${-cy})`}>
      <rect x={box.x} y={box.y + 5} width={box.w} height={box.h} rx={box.h / 2} fill="rgba(0,0,0,.25)" />
      <rect x={box.x} y={box.y} width={box.w} height={box.h} rx={box.h / 2} fill={bg} stroke={INK} strokeWidth={5} />
      <text x={cx} y={cy + fs * 0.35} textAnchor="middle" fontSize={fs} fontWeight={900} fill={fg} fontFamily={FONT}>
        {text}
      </text>
    </g>
  );
};

const wrap = (text: string, perLine: number): string[] => {
  const out: string[] = [];
  let cur = '';
  for (const w of text.split(/\s+/)) {
    if ((cur + ' ' + w).trim().length > perLine && cur) {
      out.push(cur);
      cur = w;
    } else cur = (cur + ' ' + w).trim();
  }
  if (cur) out.push(cur);
  return out;
};

const Bubble: React.FC<{a: ActorState; frame: number}> = ({a, frame}) => {
  const b = a.spec.bubble;
  const box = bubbleBox(a);
  if (!b || !box) return null;
  const hb = headBox(a);
  const s = pop(frame, 3);
  const cx = box.x + box.w / 2;
  const cy = box.y + box.h;
  const side = a.flip ? -1 : 1;
  const tailX = hb.x + hb.w / 2 + side * hb.w * 0.5;
  const lines = b.text ? wrap(b.text, 19) : [];
  return (
    <g transform={`translate(${cx} ${cy}) scale(${s}) translate(${-cx} ${-cy})`}>
      {b.type === 'speech' ? (
        <polygon points={`${tailX},${hb.y + 6} ${tailX + side * 30},${box.y + box.h - 6} ${tailX + side * 78},${box.y + box.h - 6}`} fill="#fff" stroke={INK} strokeWidth={5} strokeLinejoin="round" />
      ) : (
        <>
          <circle cx={tailX + side * 6} cy={hb.y + 2} r={9} fill="#fff" stroke={INK} strokeWidth={4} />
          <circle cx={tailX + side * 24} cy={box.y + box.h + 8} r={14} fill="#fff" stroke={INK} strokeWidth={4} />
        </>
      )}
      <rect x={box.x} y={box.y} width={box.w} height={box.h} rx={42} fill="#fff" stroke={INK} strokeWidth={5} />
      {b.type === 'speech' ? <rect x={tailX + side * 30 - (side < 0 ? 44 : 0)} y={box.y + box.h - 12} width={44} height={9} fill="#fff" /> : null}
      {b.icon ? (
        <Prop type={b.icon} cx={box.x + box.w / 2} cy={box.y + box.h / 2} w={96} />
      ) : (
        lines.map((l, i) => (
          <text key={i} x={box.x + box.w / 2} y={box.y + 66 + i * 48} textAnchor="middle" fontSize={40} fontWeight={900} fill={INK} fontFamily={FONT}>
            {l}
          </text>
        ))
      )}
    </g>
  );
};

const Fx: React.FC<{name: string; frame: number; seconds: number; t: number}> = ({name, frame, seconds, t}) => {
  switch (name) {
    case 'flash':
      return <rect x={0} y={0} width={W} height={H} fill="#fff" opacity={Math.max(0, 0.85 - frame * 0.14)} />;
    case 'darken':
      return <rect x={0} y={0} width={W} height={H} fill="#070818" opacity={0.42} />;
    case 'red':
      return <rect x={0} y={0} width={W} height={H} fill="#d00000" opacity={0.16 + 0.06 * Math.sin(seconds * 8)} />;
    case 'gold':
      return <rect x={0} y={0} width={W} height={H} fill="#ffc300" opacity={0.14} />;
    case 'speedlines':
      return (
        <g stroke="#fff" strokeLinecap="round" opacity={0.7}>
          {Array.from({length: 26}).map((_, i) => {
            const y = ((i * 97) % 1000) + 40;
            const len = 180 + ((i * 53) % 260);
            const x = ((i * 331 + seconds * 2600) % (W + 600)) - 300;
            return <line key={i} x1={W - x} y1={y} x2={W - x + len} y2={y} strokeWidth={4 + (i % 3) * 2} />;
          })}
        </g>
      );
    case 'rain':
      return (
        <g stroke="#cfe6ff" strokeLinecap="round" opacity={0.6}>
          {Array.from({length: 90}).map((_, i) => {
            const x = (i * 211) % (W + 200);
            const y = ((i * 137 + seconds * 1500) % (H + 200)) - 100;
            return <line key={i} x1={x} y1={y} x2={x - 16} y2={y + 46} strokeWidth={3.5} />;
          })}
        </g>
      );
    case 'snow':
      return (
        <g fill="#fff" opacity={0.85}>
          {Array.from({length: 70}).map((_, i) => {
            const x = ((i * 271) % W) + Math.sin(seconds * 1.4 + i) * 26;
            const y = ((i * 149 + seconds * 150) % (H + 60)) - 30;
            return <circle key={i} cx={x} cy={y} r={3 + (i % 4)} />;
          })}
        </g>
      );
    case 'sparkles':
      return (
        <g fill="#fff6b0">
          {Array.from({length: 18}).map((_, i) => {
            const x = (i * 389) % W;
            const y = (i * 223) % (H - 200);
            const s = Math.max(0, Math.sin(seconds * 5 + i * 1.3)) * (10 + (i % 4) * 5);
            return <path key={i} d={`M${x} ${y - s}L${x + s * 0.28} ${y - s * 0.28}L${x + s} ${y}L${x + s * 0.28} ${y + s * 0.28}L${x} ${y + s}L${x - s * 0.28} ${y + s * 0.28}L${x - s} ${y}L${x - s * 0.28} ${y - s * 0.28}z`} />;
          })}
        </g>
      );
    case 'confetti':
      return (
        <g>
          {Array.from({length: 70}).map((_, i) => {
            const colors = ['#ff595e', '#ffca3a', '#8ac926', '#1982c4', '#c77dff'];
            const x = ((i * 277) % W) + Math.sin(seconds * 3 + i) * 30;
            const y = ((i * 131 + seconds * 520) % (H + 100)) - 50;
            return <rect key={i} x={x} y={y} width={16} height={26} rx={3} fill={colors[i % 5]} transform={`rotate(${seconds * 300 + i * 40} ${x + 8} ${y + 13})`} />;
          })}
        </g>
      );
    case 'hearts':
      return (
        <g fill="#ff4d6d" opacity={0.9}>
          {Array.from({length: 14}).map((_, i) => {
            const x = ((i * 353) % (W - 200)) + 100 + Math.sin(seconds * 2 + i) * 20;
            const y = H - (((i * 167 + seconds * 220) % (H + 120)) - 60);
            const s = 0.5 + (i % 3) * 0.25;
            return <path key={i} transform={`translate(${x} ${y}) scale(${s})`} d="M0 30C-40 2-48-18-42-34-34-54-10-54 0-36 10-54 34-54 42-34 48-18 40 2 0 30z" />;
          })}
        </g>
      );
    case 'freeze':
      return <rect x={0} y={0} width={W} height={H} fill="#7fb8ff" opacity={0.22} style={{mixBlendMode: 'color'}} />;
    case 'glitch': {
      const on = Math.floor(seconds * 14) % 3 === 0;
      return on ? (
        <g opacity={0.5}>
          <rect x={0} y={(seconds * 900) % H} width={W} height={26} fill="#00f5d4" />
          <rect x={0} y={(seconds * 1400 + 300) % H} width={W} height={14} fill="#f15bb5" />
        </g>
      ) : null;
    }
    case 'fade-in':
      return <rect x={0} y={0} width={W} height={H} fill="#000" opacity={Math.max(0, 1 - frame / 10)} />;
    case 'fade-out':
      return <rect x={0} y={0} width={W} height={H} fill="#000" opacity={clamp01((t - 0.72) / 0.28)} />;
    default:
      return null;
  }
};

export const FX_NAMES = ['flash', 'darken', 'red', 'gold', 'speedlines', 'rain', 'snow', 'sparkles', 'confetti', 'hearts', 'freeze', 'glitch', 'fade-in', 'fade-out'];

const ScreenText: React.FC<{shot: ShotSpec; frame: number; t: number}> = ({shot, frame, t}) => {
  const tx = shot.text;
  if (!tx) return null;
  const st = TEXT_STYLE[tx.style ?? 'title'];
  let value = tx.value;
  if (tx.count) {
    const v = tx.count.from + (tx.count.to - tx.count.from) * clamp01(t / 0.75);
    value = `${tx.count.prefix ?? ''}${formatNumber(v, tx.count.to)}${tx.count.suffix ?? ''}`;
  }
  const pos = tx.pos ?? 'top';
  const s = pop(frame, 1);
  const color = tx.color ?? (tx.style === 'impact' ? '#ffdd33' : '#ffffff');
  return (
    <div
      style={{
        position: 'absolute',
        left: '4%',
        right: '4%',
        top: pos === 'top' ? 60 : pos === 'center' ? 0 : undefined,
        bottom: pos === 'bottom' ? 96 : pos === 'center' ? 0 : undefined,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        textAlign: 'center',
      }}
    >
      <div
        style={{
          fontFamily: FONT,
          fontWeight: 900,
          fontSize: st.size,
          lineHeight: 1.1,
          color,
          maxWidth: st.maxChars * st.size * 0.6,
          WebkitTextStroke: `${Math.round(st.size * 0.13)}px ${INK}`,
          paintOrder: 'stroke fill',
          textShadow: `0 ${Math.round(st.size * 0.07)}px 0 rgba(0,0,0,.35)`,
          transform: `scale(${s})`,
          letterSpacing: tx.style === 'note' ? 0 : -1,
          textTransform: tx.style === 'impact' ? 'uppercase' : 'none',
        }}
      >
        {value}
      </div>
    </div>
  );
};

export const Shot: React.FC<{
  shot: ShotSpec;
  frame: number;
  frames: number;
  fps: number;
  seconds: number; // global time, keeps idle motion continuous across cuts
  hero: string;
  characters: Record<string, CharacterDef>;
  uid: string;
  punch?: boolean;
}> = ({shot, frame, frames, fps, seconds, hero, characters, uid, punch = true}) => {
  const t = frames > 1 ? frame / (frames - 1) : 0;
  const local = frame / fps;
  const time = shot.time ?? 'sunset';
  const pal = PALETTES[time] ?? PALETTES.sunset;
  const specs: ActorSpec[] = shot.actors ?? [];
  const actors = specs.map((s, i) => actorAt(s, t, seconds, i));
  const startActors = specs.map((s, i) => actorAt(s, 0, 0, i));
  const focus = resolveFocus(shot, startActors, hero);
  const cam = cameraAt(shot, focus, t, seconds);
  const punchIn = punch ? 1 + 0.035 * Math.max(0, 1 - frame / 5) : 1;
  const z = cam.zoom * punchIn;
  const order = actors.map((a, i) => ({a, i})).sort((p, q) => (p.a.spec.z ?? p.a.scale) - (q.a.spec.z ?? q.a.scale));
  const glow = time === 'night' ? 'rgba(170,200,255,.55)' : 'rgba(255,236,190,.6)';
  const crowd = shot.crowd;
  const crowdN = Math.min(14, crowd?.count ?? 0);

  return (
    <div style={{position: 'absolute', inset: 0, overflow: 'hidden', background: '#000'}}>
      <svg viewBox={`0 0 ${W} ${H}`} width={W} height={H} style={{position: 'absolute', inset: 0}}>
        <g transform={`translate(${W / 2} ${H / 2}) scale(${z}) translate(${-cam.cx} ${-cam.cy})`}>
          <Background bg={shot.bg} time={time} seconds={seconds} uid={uid} />
          {/* dust in the light */}
          <g fill="#fff" opacity={0.5}>
            {Array.from({length: 16}).map((_, i) => (
              <circle key={i} cx={((i * 263 + seconds * 14) % W)} cy={((i * 173 + Math.sin(seconds * 0.6 + i) * 30) % 700) + 60} r={2 + (i % 3)} opacity={0.35 + 0.3 * Math.sin(seconds + i)} />
            ))}
          </g>
          {(shot.props ?? [])
            .filter((p) => p.layer === 'back')
            .map((p, i) => {
              const s = propAt(p, t);
              return <Prop key={`pb${i}`} type={p.type} cx={s.cx} cy={s.cy} w={s.w} rot={s.rot} text={p.text} />;
            })}
          {crowdN > 0
            ? Array.from({length: crowdN}).map((_, i) => {
                const x = 6 + (88 / Math.max(1, crowdN - 1)) * i + (i % 2 ? 1.5 : -1.5);
                const spec: ActorSpec = {
                  who: 'extra',
                  x: crowdN === 1 ? 50 : x,
                  y: -70 - (i % 3) * 14,
                  scale: (crowd?.scale ?? 0.66) * (0.94 + (i % 4) * 0.04),
                  pose: crowd?.pose ?? (i % 3 === 0 ? 'relaxed' : 'stand'),
                  face: i % 2 ? 'left' : 'right',
                  label: crowd?.labels?.[i % (crowd.labels.length || 1)],
                };
                const st = actorAt(spec, t, seconds, i + 20);
                const lb = labelBox(st, t);
                return (
                  <g key={`c${i}`} opacity={0.96}>
                    <Character state={st} def={{top: 'tshirt', topColor: CROWD_TOPS[i % CROWD_TOPS.length], bottom: 'pants', bottomColor: '#4a5068', line: '#3a3d4d'}} seconds={seconds} idx={i + 20} />
                    {lb ? <Pill box={lb} text={labelText(spec.label, t)} color="white" frame={frame - i} /> : null}
                  </g>
                );
              })
            : null}
          {order.map(({a, i}) => {
            const def = characters[a.spec.who] ?? characters.extra ?? {};
            const spin = a.spec.motion === 'spin' ? `rotate(${local * 540} ${a.x} ${a.groundY - 190 * a.scale})` : undefined;
            const popS = a.spec.motion === 'pop' ? pop(frame) : 1;
            const tr = [spin, popS !== 1 ? `translate(${a.x} ${a.groundY}) scale(${popS}) translate(${-a.x} ${-a.groundY})` : undefined].filter(Boolean).join(' ');
            return (
              <g key={`a${i}`} transform={tr || undefined} opacity={a.spec.ghost ? 0.45 : 1} style={{filter: `drop-shadow(0 0 ${a.spec.glow ? 26 : 13}px ${a.spec.glow ?? glow})`}}>
                <ellipse cx={a.x} cy={Math.max(a.groundY, GROUND + (a.spec.y ?? 0)) + 6} rx={78 * a.scale} ry={13 * a.scale} fill={pal.ink} opacity={0.22} />
                <Character state={a} def={def} seconds={seconds} idx={i} />
              </g>
            );
          })}
          {(shot.props ?? [])
            .filter((p) => p.layer !== 'back')
            .map((p, i) => {
              const s = propAt(p, t);
              return <Prop key={`pf${i}`} type={p.type} cx={s.cx} cy={s.cy} w={s.w} rot={s.rot} text={p.text} />;
            })}
          {actors.map((a, i) => {
            const lb = labelBox(a, t);
            const lab = a.spec.label;
            return (
              <g key={`l${i}`}>
                {lb ? <Pill box={lb} text={labelText(lab, t)} color={typeof lab === 'object' ? lab.color : undefined} frame={frame} /> : null}
                <Bubble a={a} frame={frame} />
              </g>
            );
          })}
        </g>
        <defs>
          <radialGradient id={`${uid}vg`} cx="0.5" cy="0.5" r="0.75">
            <stop offset="0.55" stopColor="rgba(0,0,0,0)" />
            <stop offset="1" stopColor="rgba(10,6,24,.5)" />
          </radialGradient>
        </defs>
        {(shot.fx ?? []).map((f, i) => (
          <Fx key={i} name={f} frame={frame} seconds={seconds} t={t} />
        ))}
        <rect x={0} y={0} width={W} height={H} fill={`url(#${uid}vg)`} />
      </svg>
      <ScreenText shot={shot} frame={frame} t={t} />
      {shot.source ? (
        <div style={{position: 'absolute', left: 0, right: 0, bottom: 34, display: 'flex', justifyContent: 'center'}}>
          <div style={{fontFamily: 'Arial, "DejaVu Sans", sans-serif', fontWeight: 700, fontSize: 34, color: '#fff', background: 'rgba(15,16,28,.78)', padding: '10px 26px', borderRadius: 999, maxWidth: '86%', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis'}}>
            Source: {shot.source}
          </div>
        </div>
      ) : null}
    </div>
  );
};
