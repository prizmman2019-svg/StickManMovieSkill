---
description: Make a what-if cartoon from one idea (script, voice, storyboard, animation, sound, mp4)
---

Load the skill `what-if` with the skill tool (if the tool is unavailable, read the file
`.opencode/skills/what-if/SKILL.md`) and follow it step by step, from Step 0 to Step 7,
without stopping to ask me questions.

My idea: $ARGUMENTS

If the idea above is empty, ask me for one "what if ..." question and then start.
